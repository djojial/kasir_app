import 'dart:typed_data';

Future<void> savePdfBytesWebImpl(Uint8List bytes, String filename) async {
  throw UnsupportedError('Web download only.');
}
