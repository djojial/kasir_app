import 'dart:typed_data';

Future<String?> savePdfToDownloadsImpl(Uint8List bytes, String filename) async {
  return null;
}
